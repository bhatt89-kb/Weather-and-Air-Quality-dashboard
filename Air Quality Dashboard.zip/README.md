
  # Air Quality Dashboard

  This is a code bundle for Air Quality Dashboard. The original project is available at https://www.figma.com/design/uhyOjrGNII3cxxBuBVaNhc/Air-Quality-Dashboard.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  