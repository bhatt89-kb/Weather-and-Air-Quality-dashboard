import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Cloud, Loader2, RotateCw } from 'lucide-react';
import { Button } from './components/ui/button';
import { Alert, AlertDescription } from './components/ui/alert';
import { SearchLocation } from './components/SearchLocation';
import { CurrentWeather } from './components/CurrentWeather';
import { AirQuality } from './components/AirQuality';
import { WeatherForecast } from './components/WeatherForecast';
import { ThemeToggle } from './components/ThemeToggle';
import { 
  WeatherData, 
  ForecastDay, 
  HourlyData, 
  getCurrentWeather, 
  getWeatherForecast, 
  getHourlyForecast 
} from './utils/weather';
import { ImageWithFallback } from './components/figma/ImageWithFallback';
import { MountainBackground } from './components/MountainBackground';
import { AtmosphericEffects } from './components/AtmosphericEffects';

export default function App() {
  const [currentCity, setCurrentCity] = useState('New York');
  const [weatherData, setWeatherData] = useState<WeatherData | null>(null);
  const [dailyForecast, setDailyForecast] = useState<ForecastDay[]>([]);
  const [hourlyForecast, setHourlyForecast] = useState<HourlyData[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [lastUpdated, setLastUpdated] = useState<Date>(new Date());

  const fetchWeatherData = async (city: string) => {
    setIsLoading(true);
    setError(null);
    
    try {
      const [weather, forecast, hourly] = await Promise.all([
        getCurrentWeather(city),
        getWeatherForecast(city),
        getHourlyForecast(city)
      ]);
      
      setWeatherData(weather);
      setDailyForecast(forecast);
      setHourlyForecast(hourly);
      setLastUpdated(new Date());
    } catch (error) {
      setError('Failed to fetch weather data. Please try again.');
      console.error('Weather fetch error:', error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchWeatherData(currentCity);
  }, [currentCity]);

  const handleLocationChange = (city: string) => {
    setCurrentCity(city);
  };

  const handleRefresh = () => {
    fetchWeatherData(currentCity);
  };

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Mountain Landscape Background */}
      <MountainBackground />
      
      {/* Atmospheric Effects */}
      <AtmosphericEffects />
      


      <div className="relative z-10">
        {/* Header */}
        <motion.header
          initial={{ opacity: 0, y: -50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, type: "spring", stiffness: 100 }}
          className="sticky top-0 bg-background/70 backdrop-blur-lg border-b border-border/30 z-50 shadow-2xl shadow-black/10 dark:shadow-white/5"
        >
          <div className="max-w-7xl mx-auto px-4 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <motion.div
                  whileHover={{ 
                    rotate: 360,
                    scale: 1.1,
                    boxShadow: "0 0 20px rgba(59, 130, 246, 0.5)"
                  }}
                  animate={{
                    boxShadow: [
                      "0 0 0px rgba(59, 130, 246, 0)",
                      "0 0 10px rgba(59, 130, 246, 0.3)",
                      "0 0 0px rgba(59, 130, 246, 0)"
                    ]
                  }}
                  transition={{ 
                    duration: 0.5,
                    boxShadow: { duration: 3, repeat: Infinity }
                  }}
                  className="p-2 bg-primary rounded-lg"
                >
                  <Cloud className="h-6 w-6 text-primary-foreground" />
                </motion.div>
                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.3, duration: 0.6 }}
                >
                  <motion.h1 
                    className="text-2xl font-bold bg-gradient-to-r from-primary via-blue-600 to-purple-600 bg-clip-text text-transparent"
                    animate={{
                      backgroundPosition: ["0% 50%", "100% 50%", "0% 50%"]
                    }}
                    transition={{
                      duration: 3,
                      repeat: Infinity,
                      ease: "linear"
                    }}
                    style={{ backgroundSize: "200% 200%" }}
                  >
                    WeatherScope
                  </motion.h1>
                  <p className="text-sm text-muted-foreground">Air Quality & Weather Dashboard</p>
                </motion.div>
              </div>

              <motion.div 
                className="flex items-center gap-4"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.4, duration: 0.6 }}
              >
                <SearchLocation 
                  onLocationSelect={handleLocationChange}
                  currentLocation={currentCity}
                />
                <motion.div
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={handleRefresh}
                    disabled={isLoading}
                    className="relative overflow-hidden"
                  >
                    {isLoading ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <motion.div
                        whileHover={{ rotate: 360 }}
                        transition={{ duration: 0.6, type: "spring" }}
                      >
                        <RotateCw className="h-4 w-4" />
                      </motion.div>
                    )}
                  </Button>
                </motion.div>
                <ThemeToggle />
              </motion.div>
            </div>
          </div>
        </motion.header>

        {/* Main Content */}
        <main className="max-w-7xl mx-auto px-4 py-8 space-y-8">
          <AnimatePresence mode="wait">
            {error ? (
              <motion.div
                key="error"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ duration: 0.3 }}
              >
                <Alert variant="destructive">
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              </motion.div>
            ) : (
              <motion.div
                key="content"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.5 }}
                className="space-y-8"
              >
                {/* Current Weather and Air Quality */}
                <motion.div 
                  className="grid grid-cols-1 lg:grid-cols-3 gap-6"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ staggerChildren: 0.1 }}
                >
                  <motion.div 
                    className="lg:col-span-2"
                    initial={{ opacity: 0, x: -50 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.6, delay: 0.2 }}
                  >
                    <CurrentWeather weatherData={weatherData} isLoading={isLoading} />
                  </motion.div>
                  <motion.div
                    initial={{ opacity: 0, x: 50 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.6, delay: 0.4 }}
                  >
                    <AirQuality weatherData={weatherData} isLoading={isLoading} />
                  </motion.div>
                </motion.div>

                {/* Forecast */}
                <motion.div
                  initial={{ opacity: 0, y: 50 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 0.6 }}
                >
                  <WeatherForecast 
                    dailyForecast={dailyForecast}
                    hourlyForecast={hourlyForecast}
                    isLoading={isLoading}
                  />
                </motion.div>
              </motion.div>
            )}
          </AnimatePresence>
        </main>

        {/* Footer */}
        <motion.footer
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1, duration: 0.5 }}
          className="mt-16 border-t border-border bg-muted/30 backdrop-blur-sm"
        >
          <div className="max-w-7xl mx-auto px-4 py-8">
            <div className="flex items-center justify-between text-sm text-muted-foreground">
              <div className="flex items-center gap-4">
                <span>© 2025 WeatherScope Dashboard</span>
                <span>•</span>
                <span>Last updated: {lastUpdated.toLocaleTimeString()}</span>
              </div>
              <div className="flex items-center gap-2">
                <span>Powered by</span>
                <motion.span
                  whileHover={{ scale: 1.05 }}
                  className="font-medium text-foreground"
                >
                  Weather API
                </motion.span>
              </div>
            </div>
          </div>
        </motion.footer>
      </div>
    </div>
  );
}