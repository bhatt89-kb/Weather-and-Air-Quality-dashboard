import React from 'react';
import { motion } from 'motion/react';
import { Activity, AlertTriangle, CheckCircle } from 'lucide-react';
import { Card } from './ui/card';
import { Progress } from './ui/progress';
import { Badge } from './ui/badge';
import { WeatherData, getAQIColor, getAQIBgColor } from '../utils/weather';
import { FloatingCard } from './FloatingCard';

interface AirQualityProps {
  weatherData: WeatherData;
  isLoading?: boolean;
}

export function AirQuality({ weatherData, isLoading }: AirQualityProps) {
  if (isLoading) {
    return (
      <Card className="p-6">
        <div className="animate-pulse">
          <div className="h-6 bg-muted rounded mb-4 w-1/2"></div>
          <div className="h-16 bg-muted rounded mb-4"></div>
          <div className="space-y-3">
            <div className="h-4 bg-muted rounded"></div>
            <div className="h-4 bg-muted rounded"></div>
            <div className="h-4 bg-muted rounded"></div>
          </div>
        </div>
      </Card>
    );
  }

  const { airQuality } = weatherData;
  const aqiPercentage = (airQuality.aqi / 300) * 100;

  const getAQIIcon = () => {
    if (airQuality.aqi <= 50) return CheckCircle;
    if (airQuality.aqi <= 100) return Activity;
    return AlertTriangle;
  };

  const AQIIcon = getAQIIcon();

  const pollutants = [
    { name: 'PM2.5', value: airQuality.pm25, unit: 'μg/m³', max: 100 },
    { name: 'PM10', value: airQuality.pm10, unit: 'μg/m³', max: 150 },
    { name: 'CO', value: airQuality.co, unit: 'mg/m³', max: 10 },
    { name: 'NO2', value: airQuality.no2, unit: 'μg/m³', max: 50 },
    { name: 'O3', value: airQuality.o3, unit: 'μg/m³', max: 200 },
    { name: 'SO2', value: airQuality.so2, unit: 'μg/m³', max: 30 },
  ];

  return (
    <FloatingCard delay={0.3}>
      <Card className="p-6 border-2 border-border/50 backdrop-blur-sm">
        <div className="flex items-center gap-3 mb-6">
          <Activity className="h-5 w-5 text-muted-foreground" />
          <h3 className="text-lg font-semibold">Air Quality Index</h3>
        </div>

        {/* AQI Score */}
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.3, duration: 0.5, type: "spring" }}
          className="text-center mb-6"
        >
          <div className="relative inline-flex items-center justify-center">
            <svg className="w-32 h-32 transform -rotate-90" viewBox="0 0 36 36">
              <path
                className="text-muted stroke-current"
                fill="none"
                strokeWidth="3"
                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
              />
              <motion.path
                className={getAQIColor(airQuality.aqi).replace('text-', 'stroke-')}
                fill="none"
                strokeWidth="3"
                strokeLinecap="round"
                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                initial={{ strokeDasharray: `0 100` }}
                animate={{ strokeDasharray: `${aqiPercentage} 100` }}
                transition={{ delay: 0.5, duration: 1, ease: "easeInOut" }}
              />
            </svg>
            <div className="absolute inset-0 flex items-center justify-center flex-col">
              <div className={`text-3xl font-bold ${getAQIColor(airQuality.aqi)}`}>
                {airQuality.aqi}
              </div>
              <AQIIcon className={`h-5 w-5 mt-1 ${getAQIColor(airQuality.aqi)}`} />
            </div>
          </div>
          <Badge 
            variant="outline" 
            className={`mt-3 ${getAQIBgColor(airQuality.aqi)} text-white border-0`}
          >
            {airQuality.quality}
          </Badge>
        </motion.div>

        {/* Pollutant Details */}
        <div className="space-y-4">
          <h4 className="font-medium text-sm text-muted-foreground">Pollutant Levels</h4>
          <div className="grid grid-cols-2 gap-4">
            {pollutants.map((pollutant, index) => (
              <motion.div
                key={pollutant.name}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.6 + index * 0.1, duration: 0.4 }}
                className="space-y-2"
              >
                <div className="flex justify-between text-sm">
                  <span className="font-medium">{pollutant.name}</span>
                  <span className="text-muted-foreground">
                    {pollutant.value} {pollutant.unit}
                  </span>
                </div>
                <div className="relative">
                  <Progress 
                    value={(pollutant.value / pollutant.max) * 100} 
                    className="h-2"
                  />
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Health Recommendation */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.2, duration: 0.4 }}
          className="mt-6 p-4 bg-muted rounded-lg"
        >
          <h4 className="font-medium mb-2 text-sm">Health Recommendation</h4>
          <p className="text-sm text-muted-foreground">
            {airQuality.aqi <= 50 && "Air quality is good. Ideal conditions for outdoor activities."}
            {airQuality.aqi > 50 && airQuality.aqi <= 100 && "Air quality is moderate. Sensitive individuals should consider limiting prolonged outdoor activities."}
            {airQuality.aqi > 100 && airQuality.aqi <= 150 && "Air quality is unhealthy for sensitive groups. Sensitive individuals should avoid prolonged outdoor activities."}
            {airQuality.aqi > 150 && airQuality.aqi <= 200 && "Air quality is unhealthy. Everyone should limit prolonged outdoor activities."}
            {airQuality.aqi > 200 && "Air quality is very unhealthy. Avoid outdoor activities and stay indoors."}
          </p>
        </motion.div>
      </Card>
    </FloatingCard>
  );
}