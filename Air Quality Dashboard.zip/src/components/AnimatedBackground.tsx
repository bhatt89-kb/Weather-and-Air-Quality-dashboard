import React from 'react';
import { motion } from 'motion/react';

export function AnimatedBackground() {
  // Generate multiple floating particles
  const particles = Array.from({ length: 15 }, (_, i) => ({
    id: i,
    size: Math.random() * 40 + 20,
    initialX: Math.random() * window.innerWidth,
    initialY: Math.random() * window.innerHeight,
    emoji: ['☁️', '🌤️', '⛅', '🌥️', '💨', '❄️', '🌧️'][Math.floor(Math.random() * 7)],
    duration: Math.random() * 20 + 15,
    delay: Math.random() * 10,
  }));

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden">
      {/* Gradient overlay */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 2 }}
        className="absolute inset-0 bg-gradient-to-br from-blue-500/5 via-transparent to-purple-500/5"
      />

      {/* Floating particles */}
      {particles.map((particle) => (
        <motion.div
          key={particle.id}
          initial={{ 
            x: particle.initialX,
            y: particle.initialY,
            opacity: 0,
            scale: 0,
            rotate: 0
          }}
          animate={{ 
            x: [
              particle.initialX,
              particle.initialX + Math.sin(particle.id) * 200,
              particle.initialX + Math.sin(particle.id + 1) * 150,
              particle.initialX
            ],
            y: [
              particle.initialY,
              particle.initialY - 100,
              particle.initialY - 50,
              particle.initialY
            ],
            opacity: [0, 0.1, 0.15, 0.1, 0],
            scale: [0, 1, 1.2, 1, 0],
            rotate: [0, 180, 360]
          }}
          transition={{ 
            duration: particle.duration,
            repeat: Infinity,
            ease: "easeInOut",
            delay: particle.delay
          }}
          className="absolute pointer-events-none"
          style={{ fontSize: `${particle.size}px` }}
        >
          {particle.emoji}
        </motion.div>
      ))}

      {/* Animated waves */}
      <motion.div
        animate={{
          x: [0, 100, 0],
          y: [0, -20, 0],
        }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: "easeInOut"
        }}
        className="absolute top-0 left-0 w-full h-32 opacity-10"
      >
        <svg viewBox="0 0 1200 120" className="w-full h-full">
          <path
            d="M0,0V46.29c47.79,22.2,103.59,32.17,158,28,70.36-5.37,136.33-33.31,206.8-37.5C438.64,32.43,512.34,53.67,583,72.05c69.27,18,138.3,24.88,209.4,13.08,36.15-6,69.85-17.84,104.45-29.34C989.49,25,1113-14.29,1200,52.47V0Z"
            fill="currentColor"
            className="text-blue-500/20"
          />
        </svg>
      </motion.div>

      <motion.div
        animate={{
          x: [0, -80, 0],
          y: [0, 15, 0],
        }}
        transition={{
          duration: 12,
          repeat: Infinity,
          ease: "easeInOut",
          delay: 2
        }}
        className="absolute bottom-0 left-0 w-full h-32 opacity-10 rotate-180"
      >
        <svg viewBox="0 0 1200 120" className="w-full h-full">
          <path
            d="M0,0V46.29c47.79,22.2,103.59,32.17,158,28,70.36-5.37,136.33-33.31,206.8-37.5C438.64,32.43,512.34,53.67,583,72.05c69.27,18,138.3,24.88,209.4,13.08,36.15-6,69.85-17.84,104.45-29.34C989.49,25,1113-14.29,1200,52.47V0Z"
            fill="currentColor"
            className="text-purple-500/20"
          />
        </svg>
      </motion.div>

      {/* Twinkling stars */}
      {Array.from({ length: 8 }, (_, i) => (
        <motion.div
          key={`star-${i}`}
          initial={{ opacity: 0, scale: 0 }}
          animate={{ 
            opacity: [0, 1, 0],
            scale: [0, 1, 0],
          }}
          transition={{
            duration: 3,
            repeat: Infinity,
            delay: i * 0.5,
            ease: "easeInOut"
          }}
          className="absolute text-yellow-400/30"
          style={{
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
            fontSize: `${Math.random() * 10 + 10}px`
          }}
        >
          ✨
        </motion.div>
      ))}
    </div>
  );
}