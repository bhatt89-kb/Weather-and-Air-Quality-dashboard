import React from 'react';
import { motion } from 'motion/react';

export function AtmosphericEffects() {
  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden">
      {/* Mist/Fog Effects */}
      <motion.div
        animate={{
          x: [0, 100, 0],
          opacity: [0.1, 0.3, 0.1],
        }}
        transition={{
          duration: 12,
          repeat: Infinity,
          ease: "easeInOut"
        }}
        className="absolute bottom-1/4 left-0 w-full h-32 bg-gradient-to-r from-transparent via-white/20 to-transparent dark:via-gray-300/10"
        style={{
          clipPath: "polygon(0 50%, 25% 30%, 50% 60%, 75% 20%, 100% 40%, 100% 100%, 0 100%)"
        }}
      />

      <motion.div
        animate={{
          x: [0, -80, 0],
          opacity: [0.05, 0.2, 0.05],
        }}
        transition={{
          duration: 15,
          repeat: Infinity,
          ease: "easeInOut",
          delay: 3
        }}
        className="absolute bottom-1/3 right-0 w-3/4 h-24 bg-gradient-to-l from-transparent via-white/15 to-transparent dark:via-gray-400/8"
        style={{
          clipPath: "polygon(0 60%, 30% 40%, 60% 70%, 100% 30%, 100% 100%, 0 100%)"
        }}
      />

      {/* Light Rays */}
      <motion.div
        animate={{
          opacity: [0, 0.15, 0],
          rotate: [0, 2, 0],
        }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: "easeInOut"
        }}
        className="absolute top-20 right-1/3 w-1 h-96 bg-gradient-to-b from-yellow-200/40 to-transparent dark:from-gray-200/20 origin-top"
        style={{ transform: "rotate(-15deg)" }}
      />

      <motion.div
        animate={{
          opacity: [0, 0.1, 0],
          rotate: [0, -1, 0],
        }}
        transition={{
          duration: 10,
          repeat: Infinity,
          ease: "easeInOut",
          delay: 2
        }}
        className="absolute top-24 right-1/4 w-0.5 h-80 bg-gradient-to-b from-yellow-300/30 to-transparent dark:from-gray-300/15 origin-top"
        style={{ transform: "rotate(-25deg)" }}
      />

      {/* Floating Embers/Particles */}
      {Array.from({ length: 6 }, (_, i) => (
        <motion.div
          key={`ember-${i}`}
          initial={{ 
            opacity: 0,
            x: Math.random() * window.innerWidth,
            y: window.innerHeight + 20
          }}
          animate={{ 
            opacity: [0, 0.6, 0.3, 0],
            x: Math.random() * window.innerWidth + 50,
            y: -20,
            scale: [0.5, 1, 0.8, 0.3],
          }}
          transition={{
            duration: Math.random() * 20 + 15,
            repeat: Infinity,
            delay: Math.random() * 8,
            ease: "easeOut"
          }}
          className="absolute w-1 h-1 rounded-full"
          style={{
            background: `radial-gradient(circle, ${
              Math.random() > 0.5 
                ? 'rgba(255, 165, 0, 0.8)' 
                : 'rgba(255, 255, 255, 0.6)'
            } 0%, transparent 70%)`
          }}
        />
      ))}

      {/* Color Temperature Overlay */}
      <motion.div
        animate={{
          opacity: [0.05, 0.15, 0.05],
        }}
        transition={{
          duration: 20,
          repeat: Infinity,
          ease: "easeInOut"
        }}
        className="absolute inset-0 bg-gradient-to-t from-orange-200/20 via-transparent to-blue-200/10 dark:from-purple-900/20 dark:via-transparent dark:to-indigo-900/10"
      />
    </div>
  );
}