import React from 'react';
import { motion } from 'motion/react';
import { Thermometer, Droplets, Wind, Eye, Gauge, Sun, MapPin } from 'lucide-react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { WeatherData, getWeatherIcon, getAQIColor } from '../utils/weather';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { FloatingCard } from './FloatingCard';

interface CurrentWeatherProps {
  weatherData: WeatherData;
  isLoading?: boolean;
}

export function CurrentWeather({ weatherData, isLoading }: CurrentWeatherProps) {
  if (isLoading) {
    return (
      <Card className="p-6 bg-gradient-to-br from-card via-card to-muted">
        <div className="animate-pulse">
          <div className="h-6 bg-muted rounded mb-4 w-1/3"></div>
          <div className="h-20 bg-muted rounded mb-6 w-1/2"></div>
          <div className="space-y-3">
            <div className="h-4 bg-muted rounded w-full"></div>
            <div className="h-4 bg-muted rounded w-3/4"></div>
            <div className="h-4 bg-muted rounded w-1/2"></div>
          </div>
        </div>
      </Card>
    );
  }

  const weatherStats = [
    { icon: Thermometer, label: 'Feels like', value: `${weatherData.feelsLike}°C` },
    { icon: Droplets, label: 'Humidity', value: `${weatherData.humidity}%` },
    { icon: Wind, label: 'Wind Speed', value: `${weatherData.windSpeed} km/h` },
    { icon: Eye, label: 'Visibility', value: `${weatherData.visibility} km` },
    { icon: Gauge, label: 'Pressure', value: `${weatherData.pressure} hPa` },
    { icon: Sun, label: 'UV Index', value: weatherData.uvIndex.toString() },
  ];

  return (
    <FloatingCard delay={0.1}>
      <Card className="p-6 bg-gradient-to-br from-card via-card to-muted relative overflow-hidden border-2 border-border/50 backdrop-blur-sm">
        {/* Background Image */}
        <div className="absolute inset-0 opacity-10">
          <ImageWithFallback
            src="https://images.unsplash.com/photo-1608819667256-09f726de6938?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3ZWF0aGVyJTIwY2xvdWR5JTIwc2t5fGVufDF8fHx8MTc1Njg2Mzg2OHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
            alt="Weather background"
            className="w-full h-full object-cover"
          />
        </div>

        <div className="relative z-10">
          {/* Location */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.1, duration: 0.4 }}
            className="flex items-center gap-2 mb-4"
          >
            <MapPin className="h-4 w-4 text-muted-foreground" />
            <span className="text-muted-foreground">{weatherData.location}, {weatherData.country}</span>
          </motion.div>

          {/* Main Temperature */}
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2, duration: 0.5, type: "spring" }}
            className="flex items-center gap-4 mb-6"
          >
            <motion.div 
              className="text-6xl" 
              aria-label={weatherData.condition}
              animate={{
                rotate: [0, 5, -5, 0],
                scale: [1, 1.1, 1],
              }}
              transition={{
                duration: 3,
                repeat: Infinity,
                ease: "easeInOut"
              }}
              whileHover={{
                scale: 1.2,
                rotate: 15,
                transition: { duration: 0.3 }
              }}
            >
              {getWeatherIcon(weatherData.condition)}
            </motion.div>
            <div>
              <motion.div 
                className="text-5xl font-medium"
                animate={{
                  scale: [1, 1.02, 1],
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
              >
                {weatherData.temperature}°
              </motion.div>
              <div className="text-muted-foreground capitalize">{weatherData.condition}</div>
            </div>
          </motion.div>

          {/* Weather Stats Grid */}
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {weatherStats.map((stat, index) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 + index * 0.1, duration: 0.4 }}
                className="flex items-center gap-3 p-3 rounded-lg bg-background/50 backdrop-blur-sm border border-border/50"
              >
                <stat.icon className="h-4 w-4 text-muted-foreground" />
                <div>
                  <div className="text-sm text-muted-foreground">{stat.label}</div>
                  <div className="font-medium">{stat.value}</div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </Card>
    </FloatingCard>
  );
}