import React from 'react';
import { motion } from 'motion/react';

export function MountainBackground() {
  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden">
      {/* Sky Gradient Background */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 3 }}
        className="absolute inset-0 bg-gradient-to-b from-orange-200 via-pink-200 to-purple-300 dark:from-slate-900 dark:via-purple-900 dark:to-indigo-900"
      />

      {/* Animated Sky Colors */}
      <motion.div
        animate={{
          opacity: [0.3, 0.6, 0.3],
          scale: [1, 1.1, 1],
        }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: "easeInOut"
        }}
        className="absolute inset-0 bg-gradient-to-b from-yellow-200/40 via-orange-300/40 to-red-400/40 dark:from-blue-900/40 dark:via-purple-800/40 dark:to-slate-800/40"
      />

      {/* Celestial Elements */}
      {/* Sun/Moon */}
      <motion.div
        initial={{ y: 100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 2, delay: 1 }}
        className="absolute top-20 right-1/3 w-32 h-32 rounded-full bg-gradient-to-br from-yellow-200 to-orange-300 dark:from-gray-200 dark:to-gray-300 shadow-2xl shadow-yellow-500/50 dark:shadow-gray-300/30"
      >
        <motion.div
          animate={{
            scale: [1, 1.05, 1],
            opacity: [0.8, 1, 0.8],
          }}
          transition={{
            duration: 4,
            repeat: Infinity,
            ease: "easeInOut"
          }}
          className="w-full h-full rounded-full bg-gradient-to-br from-yellow-100 to-orange-200 dark:from-gray-100 dark:to-gray-200"
        />
      </motion.div>

      {/* Crescent Moon for Dark Mode */}
      <motion.div
        initial={{ opacity: 0, rotate: -30 }}
        animate={{ 
          opacity: 1, 
          rotate: 0,
          y: [0, -10, 0],
        }}
        transition={{ 
          duration: 2,
          delay: 1.5,
          y: { duration: 6, repeat: Infinity, ease: "easeInOut" }
        }}
        className="absolute top-16 left-1/4 w-8 h-8 dark:block hidden"
      >
        <div className="w-full h-full rounded-full bg-gray-200 shadow-lg shadow-gray-200/50 relative">
          <div className="absolute top-1 left-1 w-6 h-6 rounded-full bg-slate-900" />
        </div>
      </motion.div>

      {/* Stars for Dark Mode */}
      {Array.from({ length: 12 }, (_, i) => (
        <motion.div
          key={`star-${i}`}
          initial={{ opacity: 0, scale: 0 }}
          animate={{ 
            opacity: [0, 1, 0.5, 1, 0],
            scale: [0, 1, 0.8, 1, 0],
          }}
          transition={{
            duration: 4,
            repeat: Infinity,
            delay: i * 0.3,
            ease: "easeInOut"
          }}
          className="absolute dark:block hidden"
          style={{
            left: `${Math.random() * 80 + 10}%`,
            top: `${Math.random() * 40 + 10}%`,
          }}
        >
          <div className="w-1 h-1 bg-gray-200 rounded-full shadow-lg shadow-gray-200/50" />
        </motion.div>
      ))}

      {/* Mountain Layers - Back to Front */}
      {/* Furthest Mountains */}
      <motion.div
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 2, delay: 0.5 }}
        className="absolute bottom-0 left-0 w-full h-3/4"
      >
        <svg viewBox="0 0 1200 600" className="w-full h-full">
          <motion.path
            initial={{ pathLength: 0 }}
            animate={{ pathLength: 1 }}
            transition={{ duration: 3, delay: 1 }}
            d="M0,600 L0,350 L150,300 L300,250 L450,280 L600,200 L750,240 L900,180 L1050,220 L1200,160 L1200,600 Z"
            fill="rgba(139, 69, 19, 0.15)"
            className="dark:fill-slate-700/30"
          />
        </svg>
      </motion.div>

      {/* Second Layer */}
      <motion.div
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 2, delay: 0.7 }}
        className="absolute bottom-0 left-0 w-full h-2/3"
      >
        <svg viewBox="0 0 1200 500" className="w-full h-full">
          <motion.path
            initial={{ pathLength: 0 }}
            animate={{ pathLength: 1 }}
            transition={{ duration: 3, delay: 1.2 }}
            d="M0,500 L0,280 L200,220 L400,180 L550,200 L700,140 L850,160 L1000,120 L1200,100 L1200,500 Z"
            fill="rgba(139, 69, 19, 0.25)"
            className="dark:fill-slate-600/40"
          />
        </svg>
      </motion.div>

      {/* Third Layer */}
      <motion.div
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 2, delay: 0.9 }}
        className="absolute bottom-0 left-0 w-full h-1/2"
      >
        <svg viewBox="0 0 1200 400" className="w-full h-full">
          <motion.path
            initial={{ pathLength: 0 }}
            animate={{ pathLength: 1 }}
            transition={{ duration: 3, delay: 1.4 }}
            d="M0,400 L0,200 L180,150 L350,120 L500,140 L650,80 L800,100 L950,60 L1200,40 L1200,400 Z"
            fill="rgba(139, 69, 19, 0.4)"
            className="dark:fill-slate-500/50"
          />
        </svg>
      </motion.div>

      {/* Foreground Mountains */}
      <motion.div
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 2, delay: 1.1 }}
        className="absolute bottom-0 left-0 w-full h-2/5"
      >
        <svg viewBox="0 0 1200 300" className="w-full h-full">
          <motion.path
            initial={{ pathLength: 0 }}
            animate={{ pathLength: 1 }}
            transition={{ duration: 3, delay: 1.6 }}
            d="M0,300 L0,150 L160,100 L320,80 L480,90 L640,50 L800,60 L960,30 L1200,20 L1200,300 Z"
            fill="rgba(139, 69, 19, 0.6)"
            className="dark:fill-slate-800/70"
          />
        </svg>
      </motion.div>

      {/* Very Foreground Trees/Hills */}
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 2, delay: 1.3 }}
        className="absolute bottom-0 left-0 w-full h-1/4"
      >
        <svg viewBox="0 0 1200 200" className="w-full h-full">
          <motion.path
            initial={{ pathLength: 0 }}
            animate={{ pathLength: 1 }}
            transition={{ duration: 3, delay: 1.8 }}
            d="M0,200 L0,80 L100,60 L200,70 L300,50 L400,60 L500,40 L600,50 L700,30 L800,40 L900,20 L1000,30 L1100,15 L1200,10 L1200,200 Z"
            fill="rgba(139, 69, 19, 0.8)"
            className="dark:fill-slate-900/90"
          />
        </svg>
      </motion.div>

      {/* Floating Particles */}
      {Array.from({ length: 8 }, (_, i) => (
        <motion.div
          key={`particle-${i}`}
          initial={{ 
            opacity: 0,
            x: Math.random() * window.innerWidth,
            y: window.innerHeight + 50
          }}
          animate={{ 
            opacity: [0, 0.3, 0],
            x: Math.random() * window.innerWidth + 100,
            y: -50,
          }}
          transition={{
            duration: Math.random() * 15 + 10,
            repeat: Infinity,
            delay: Math.random() * 10,
            ease: "linear"
          }}
          className="absolute w-1 h-1 bg-white/30 dark:bg-gray-300/20 rounded-full"
        />
      ))}

      {/* Lake/Water Reflection for Dark Mode */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 3, delay: 2 }}
        className="absolute bottom-0 left-1/4 w-1/2 h-16 dark:block hidden"
      >
        <motion.div
          animate={{
            opacity: [0.3, 0.6, 0.3],
            scaleY: [1, 1.1, 1],
          }}
          transition={{
            duration: 4,
            repeat: Infinity,
            ease: "easeInOut"
          }}
          className="w-full h-full bg-gradient-to-t from-slate-700/40 to-transparent rounded-t-full"
        />
      </motion.div>

      {/* Small Cabin Light for Dark Mode */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 2, delay: 2.5 }}
        className="absolute bottom-12 left-1/3 w-3 h-2 dark:block hidden"
      >
        <motion.div
          animate={{
            opacity: [0.8, 1, 0.8],
            scale: [1, 1.1, 1],
          }}
          transition={{
            duration: 3,
            repeat: Infinity,
            ease: "easeInOut"
          }}
          className="w-full h-full bg-yellow-300 rounded-sm shadow-lg shadow-yellow-300/50"
        />
      </motion.div>

      {/* Atmospheric Glow */}
      <motion.div
        animate={{
          opacity: [0.1, 0.3, 0.1],
          scale: [1, 1.05, 1],
        }}
        transition={{
          duration: 6,
          repeat: Infinity,
          ease: "easeInOut"
        }}
        className="absolute inset-0 bg-gradient-radial from-yellow-300/20 via-transparent to-transparent dark:from-blue-400/10"
      />
    </div>
  );
}