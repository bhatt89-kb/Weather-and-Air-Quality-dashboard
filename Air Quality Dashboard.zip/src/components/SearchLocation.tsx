import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Search, MapPin, Loader2, X } from 'lucide-react';
import { Input } from './ui/input';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { searchCities, getCurrentLocation } from '../utils/weather';

interface SearchLocationProps {
  onLocationSelect: (city: string) => void;
  currentLocation?: string;
}

interface CityResult {
  name: string;
  country: string;
  coords: number[];
}

export function SearchLocation({ onLocationSelect, currentLocation }: SearchLocationProps) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<CityResult[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isGettingLocation, setIsGettingLocation] = useState(false);
  const [showResults, setShowResults] = useState(false);

  useEffect(() => {
    const searchTimeout = setTimeout(async () => {
      if (query.length > 1) {
        setIsLoading(true);
        try {
          const cities = await searchCities(query);
          setResults(cities);
          setShowResults(true);
        } catch (error) {
          console.error('Search error:', error);
        }
        setIsLoading(false);
      } else {
        setResults([]);
        setShowResults(false);
      }
    }, 300);

    return () => clearTimeout(searchTimeout);
  }, [query]);

  const handleLocationSelect = (cityName: string) => {
    onLocationSelect(cityName);
    setQuery('');
    setShowResults(false);
  };

  const handleCurrentLocation = async () => {
    setIsGettingLocation(true);
    try {
      const location = await getCurrentLocation();
      onLocationSelect(location.city);
    } catch (error) {
      console.error('Geolocation error:', error);
      // Fallback to a default city
      onLocationSelect('New York');
    }
    setIsGettingLocation(false);
  };

  const clearSearch = () => {
    setQuery('');
    setShowResults(false);
    setResults([]);
  };

  return (
    <div className="relative w-full max-w-md">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.4, type: "spring", stiffness: 200 }}
        whileHover={{ scale: 1.02 }}
        className="relative"
      >
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
          <Input
            type="text"
            placeholder="Search for a city..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="pl-10 pr-20 bg-card border-border"
          />
          {query && (
            <Button
              variant="ghost"
              size="sm"
              onClick={clearSearch}
              className="absolute right-12 top-1/2 transform -translate-y-1/2 h-6 w-6 p-0"
            >
              <X className="h-3 w-3" />
            </Button>
          )}
          {isLoading && (
            <Loader2 className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 animate-spin text-muted-foreground" />
          )}
        </div>

        <Button
          variant="outline"
          size="sm"
          onClick={handleCurrentLocation}
          disabled={isGettingLocation}
          className="absolute right-0 top-0 h-full px-3 rounded-l-none border-l-0"
        >
          {isGettingLocation ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : (
            <MapPin className="h-4 w-4" />
          )}
        </Button>
      </motion.div>

      <AnimatePresence>
        {showResults && results.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: -10, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -10, scale: 0.95 }}
            transition={{ duration: 0.2 }}
            className="absolute top-full mt-2 w-full z-50"
          >
            <Card className="p-2 shadow-lg border bg-card">
              {results.map((city, index) => (
                <motion.button
                  key={`${city.name}-${city.country}`}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.2, delay: index * 0.05 }}
                  onClick={() => handleLocationSelect(city.name)}
                  className="w-full text-left px-3 py-2 rounded hover:bg-accent transition-colors duration-150 flex items-center gap-2"
                >
                  <MapPin className="h-3 w-3 text-muted-foreground" />
                  <span>{city.name}, {city.country}</span>
                </motion.button>
              ))}
            </Card>
          </motion.div>
        )}
      </AnimatePresence>

      {currentLocation && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="mt-2 text-sm text-muted-foreground flex items-center gap-1"
        >
          <MapPin className="h-3 w-3" />
          Current: {currentLocation}
        </motion.div>
      )}
    </div>
  );
}