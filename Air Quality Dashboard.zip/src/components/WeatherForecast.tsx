import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Calendar, Clock, Droplets, Wind, TrendingUp } from 'lucide-react';
import { Card } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Badge } from './ui/badge';
import { LineChart, Line, XAxis, YAxis, ResponsiveContainer, Tooltip, Area, AreaChart } from 'recharts';
import { ForecastDay, HourlyData, getWeatherIcon } from '../utils/weather';
import { FloatingCard } from './FloatingCard';

interface WeatherForecastProps {
  dailyForecast: ForecastDay[];
  hourlyForecast: HourlyData[];
  isLoading?: boolean;
}

export function WeatherForecast({ dailyForecast, hourlyForecast, isLoading }: WeatherForecastProps) {
  const [selectedDay, setSelectedDay] = useState<number | null>(null);

  if (isLoading) {
    return (
      <Card className="p-6">
        <div className="animate-pulse">
          <div className="h-6 bg-muted rounded mb-4 w-1/3"></div>
          <div className="h-40 bg-muted rounded mb-4"></div>
          <div className="space-y-3">
            <div className="h-4 bg-muted rounded"></div>
            <div className="h-4 bg-muted rounded w-3/4"></div>
          </div>
        </div>
      </Card>
    );
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const today = new Date();
    const tomorrow = new Date(today);
    tomorrow.setDate(today.getDate() + 1);

    if (date.toDateString() === today.toDateString()) return 'Today';
    if (date.toDateString() === tomorrow.toDateString()) return 'Tomorrow';
    return date.toLocaleDateString('en-US', { weekday: 'short', day: 'numeric' });
  };

  const hourlyChartData = hourlyForecast.slice(0, 12).map(hour => ({
    time: hour.time,
    temperature: hour.temperature,
    precipitation: hour.precipitation,
  }));

  const dailyChartData = dailyForecast.map((day, index) => ({
    day: formatDate(day.date),
    high: day.high,
    low: day.low,
    avg: Math.round((day.high + day.low) / 2),
    index,
  }));

  return (
    <FloatingCard delay={0.5}>
      <Card className="p-6 border-2 border-border/50 backdrop-blur-sm">
        <div className="flex items-center gap-3 mb-6">
          <Calendar className="h-5 w-5 text-muted-foreground" />
          <h3 className="text-lg font-semibold">Weather Forecast</h3>
        </div>

        <Tabs defaultValue="daily" className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-6">
            <TabsTrigger value="daily" className="flex items-center gap-2">
              <Calendar className="h-4 w-4" />
              7-Day Forecast
            </TabsTrigger>
            <TabsTrigger value="hourly" className="flex items-center gap-2">
              <Clock className="h-4 w-4" />
              24-Hour Forecast
            </TabsTrigger>
          </TabsList>

          <TabsContent value="daily" className="space-y-6">
            {/* Daily Chart */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.4, duration: 0.5 }}
              className="h-64"
            >
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={dailyChartData}>
                  <defs>
                    <linearGradient id="tempGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <XAxis 
                    dataKey="day" 
                    axisLine={false}
                    tickLine={false}
                    tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }}
                  />
                  <YAxis 
                    axisLine={false}
                    tickLine={false}
                    tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }}
                    domain={['dataMin - 5', 'dataMax + 5']}
                  />
                  <Tooltip 
                    content={({ active, payload, label }) => {
                      if (active && payload && payload.length) {
                        return (
                          <div className="bg-card border border-border rounded-lg p-3 shadow-lg">
                            <p className="font-medium">{label}</p>
                            <p className="text-sm text-red-500">High: {payload.find(p => p.dataKey === 'high')?.value}°C</p>
                            <p className="text-sm text-blue-500">Low: {payload.find(p => p.dataKey === 'low')?.value}°C</p>
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                  <Area 
                    type="monotone" 
                    dataKey="high" 
                    stroke="hsl(var(--destructive))" 
                    strokeWidth={2}
                    fill="url(#tempGradient)"
                  />
                  <Area 
                    type="monotone" 
                    dataKey="low" 
                    stroke="hsl(var(--primary))" 
                    strokeWidth={2}
                    fillOpacity={0}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </motion.div>

            {/* Daily Cards */}
            <div className="space-y-3">
              {dailyForecast.map((day, index) => (
                <motion.div
                  key={day.date}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.5 + index * 0.1, duration: 0.4 }}
                  onClick={() => setSelectedDay(selectedDay === index ? null : index)}
                  className="p-4 rounded-lg bg-muted/50 hover:bg-muted transition-colors cursor-pointer"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="text-2xl" aria-label={day.condition}>
                        {getWeatherIcon(day.condition)}
                      </div>
                      <div>
                        <div className="font-medium">{formatDate(day.date)}</div>
                        <div className="text-sm text-muted-foreground capitalize">{day.condition}</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="text-right">
                        <div className="font-medium">{day.high}° / {day.low}°</div>
                        <div className="text-sm text-muted-foreground">{day.precipitation}% rain</div>
                      </div>
                      <TrendingUp className={`h-4 w-4 transition-transform ${selectedDay === index ? 'rotate-90' : ''}`} />
                    </div>
                  </div>

                  <AnimatePresence>
                    {selectedDay === index && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                        transition={{ duration: 0.3 }}
                        className="mt-4 pt-4 border-t border-border"
                      >
                        <div className="grid grid-cols-2 gap-4 text-sm">
                          <div className="flex items-center gap-2">
                            <Droplets className="h-4 w-4 text-blue-500" />
                            <span>Humidity: {day.humidity}%</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Wind className="h-4 w-4 text-gray-500" />
                            <span>Wind: {day.windSpeed} km/h</span>
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </motion.div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="hourly" className="space-y-6">
            {/* Hourly Chart */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.4, duration: 0.5 }}
              className="h-64"
            >
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={hourlyChartData}>
                  <XAxis 
                    dataKey="time" 
                    axisLine={false}
                    tickLine={false}
                    tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }}
                  />
                  <YAxis 
                    axisLine={false}
                    tickLine={false}
                    tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }}
                    domain={['dataMin - 2', 'dataMax + 2']}
                  />
                  <Tooltip 
                    content={({ active, payload, label }) => {
                      if (active && payload && payload.length) {
                        return (
                          <div className="bg-card border border-border rounded-lg p-3 shadow-lg">
                            <p className="font-medium">{label}</p>
                            <p className="text-sm">Temp: {payload[0]?.value}°C</p>
                            <p className="text-sm">Rain: {payload[1]?.value}%</p>
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="temperature" 
                    stroke="hsl(var(--primary))" 
                    strokeWidth={3}
                    dot={{ fill: 'hsl(var(--primary))', strokeWidth: 2, r: 4 }}
                    activeDot={{ r: 6, strokeWidth: 2 }}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="precipitation" 
                    stroke="hsl(var(--chart-2))" 
                    strokeWidth={2}
                    strokeDasharray="5 5"
                    dot={{ fill: 'hsl(var(--chart-2))', strokeWidth: 2, r: 3 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </motion.div>

            {/* Hourly Cards */}
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
              {hourlyForecast.slice(0, 8).map((hour, index) => (
                <motion.div
                  key={hour.time}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.5 + index * 0.05, duration: 0.4 }}
                  className="p-3 rounded-lg bg-muted/50 text-center"
                >
                  <div className="text-sm text-muted-foreground mb-2">{hour.time}</div>
                  <div className="text-lg mb-2" aria-label={hour.condition}>
                    {getWeatherIcon(hour.condition)}
                  </div>
                  <div className="font-medium">{hour.temperature}°</div>
                  <Badge variant="outline" className="text-xs mt-2">
                    {hour.precipitation}% rain
                  </Badge>
                </motion.div>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </Card>
    </FloatingCard>
  );
}