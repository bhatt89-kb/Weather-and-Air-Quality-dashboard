// Mock weather data service
export interface WeatherData {
  location: string;
  country: string;
  temperature: number;
  condition: string;
  humidity: number;
  windSpeed: number;
  pressure: number;
  visibility: number;
  uvIndex: number;
  feelsLike: number;
  airQuality: {
    aqi: number;
    pm25: number;
    pm10: number;
    co: number;
    no2: number;
    o3: number;
    so2: number;
    quality: string;
  };
}

export interface ForecastDay {
  date: string;
  high: number;
  low: number;
  condition: string;
  humidity: number;
  windSpeed: number;
  precipitation: number;
}

export interface HourlyData {
  time: string;
  temperature: number;
  condition: string;
  precipitation: number;
}

const mockCities = [
  { name: "New York", country: "USA", coords: [40.7128, -74.0060] },
  { name: "London", country: "UK", coords: [51.5074, -0.1278] },
  { name: "Tokyo", country: "Japan", coords: [35.6762, 139.6503] },
  { name: "Sydney", country: "Australia", coords: [-33.8688, 151.2093] },
  { name: "Paris", country: "France", coords: [48.8566, 2.3522] },
  { name: "Berlin", country: "Germany", coords: [52.5200, 13.4050] },
  { name: "Mumbai", country: "India", coords: [19.0760, 72.8777] },
  { name: "São Paulo", country: "Brazil", coords: [-23.5505, -46.6333] },
];

const conditions = ["Sunny", "Cloudy", "Partly Cloudy", "Rainy", "Thunderstorm", "Foggy", "Snowy"];
const airQualities = [
  { quality: "Good", aqi: 45, color: "green" },
  { quality: "Moderate", aqi: 85, color: "yellow" },
  { quality: "Unhealthy for Sensitive Groups", aqi: 125, color: "orange" },
  { quality: "Unhealthy", aqi: 165, color: "red" },
  { quality: "Very Unhealthy", aqi: 225, color: "purple" },
];

export const searchCities = async (query: string) => {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 300));
  
  return mockCities.filter(city => 
    city.name.toLowerCase().includes(query.toLowerCase()) ||
    city.country.toLowerCase().includes(query.toLowerCase())
  );
};

export const getCurrentWeather = async (cityName: string): Promise<WeatherData> => {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 500));
  
  const city = mockCities.find(c => c.name.toLowerCase() === cityName.toLowerCase()) || mockCities[0];
  const airQuality = airQualities[Math.floor(Math.random() * airQualities.length)];
  
  return {
    location: city.name,
    country: city.country,
    temperature: Math.floor(Math.random() * 35) + 5, // 5-40°C
    condition: conditions[Math.floor(Math.random() * conditions.length)],
    humidity: Math.floor(Math.random() * 60) + 30, // 30-90%
    windSpeed: Math.floor(Math.random() * 25) + 5, // 5-30 km/h
    pressure: Math.floor(Math.random() * 50) + 1000, // 1000-1050 hPa
    visibility: Math.floor(Math.random() * 15) + 5, // 5-20 km
    uvIndex: Math.floor(Math.random() * 11), // 0-10
    feelsLike: Math.floor(Math.random() * 35) + 3, // 3-38°C
    airQuality: {
      aqi: airQuality.aqi,
      pm25: Math.floor(Math.random() * 100) + 10,
      pm10: Math.floor(Math.random() * 150) + 20,
      co: Math.floor(Math.random() * 5) + 1,
      no2: Math.floor(Math.random() * 40) + 5,
      o3: Math.floor(Math.random() * 160) + 20,
      so2: Math.floor(Math.random() * 20) + 2,
      quality: airQuality.quality,
    }
  };
};

export const getWeatherForecast = async (cityName: string): Promise<ForecastDay[]> => {
  await new Promise(resolve => setTimeout(resolve, 400));
  
  const forecast: ForecastDay[] = [];
  const today = new Date();
  
  for (let i = 0; i < 7; i++) {
    const date = new Date(today);
    date.setDate(today.getDate() + i);
    
    forecast.push({
      date: date.toISOString().split('T')[0],
      high: Math.floor(Math.random() * 15) + 20, // 20-35°C
      low: Math.floor(Math.random() * 15) + 5, // 5-20°C
      condition: conditions[Math.floor(Math.random() * conditions.length)],
      humidity: Math.floor(Math.random() * 60) + 30,
      windSpeed: Math.floor(Math.random() * 20) + 5,
      precipitation: Math.floor(Math.random() * 100), // 0-100%
    });
  }
  
  return forecast;
};

export const getHourlyForecast = async (cityName: string): Promise<HourlyData[]> => {
  await new Promise(resolve => setTimeout(resolve, 300));
  
  const hourly: HourlyData[] = [];
  const now = new Date();
  
  for (let i = 0; i < 24; i++) {
    const time = new Date(now);
    time.setHours(now.getHours() + i);
    
    hourly.push({
      time: time.toISOString().split('T')[1].split(':')[0] + ':00',
      temperature: Math.floor(Math.random() * 20) + 15, // 15-35°C
      condition: conditions[Math.floor(Math.random() * conditions.length)],
      precipitation: Math.floor(Math.random() * 100),
    });
  }
  
  return hourly;
};

export const getCurrentLocation = async (): Promise<{ lat: number; lon: number; city: string }> => {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      reject(new Error('Geolocation is not supported'));
      return;
    }
    
    navigator.geolocation.getCurrentPosition(
      (position) => {
        // Mock city name based on coordinates
        const mockCity = mockCities[Math.floor(Math.random() * mockCities.length)];
        resolve({
          lat: position.coords.latitude,
          lon: position.coords.longitude,
          city: mockCity.name,
        });
      },
      (error) => {
        reject(error);
      }
    );
  });
};

export const getWeatherIcon = (condition: string): string => {
  const iconMap: { [key: string]: string } = {
    'Sunny': '☀️',
    'Cloudy': '☁️',
    'Partly Cloudy': '⛅',
    'Rainy': '🌧️',
    'Thunderstorm': '⛈️',
    'Foggy': '🌫️',
    'Snowy': '❄️',
  };
  return iconMap[condition] || '🌤️';
};

export const getAQIColor = (aqi: number): string => {
  if (aqi <= 50) return 'text-green-500';
  if (aqi <= 100) return 'text-yellow-500';
  if (aqi <= 150) return 'text-orange-500';
  if (aqi <= 200) return 'text-red-500';
  return 'text-purple-500';
};

export const getAQIBgColor = (aqi: number): string => {
  if (aqi <= 50) return 'bg-green-500';
  if (aqi <= 100) return 'bg-yellow-500';
  if (aqi <= 150) return 'bg-orange-500';
  if (aqi <= 200) return 'bg-red-500';
  return 'bg-purple-500';
};